import { RiLoginBoxLine } from "react-icons/ri";
import { Link } from "react-router-dom";
import { BiLeftArrow } from "react-icons/bi";
import { BiArrowFromLeft } from "react-icons/bi";


 
 const Courses = ()=>{
    return(
        <div className="bg-zinc-100 pt-32 px-12 w-full pb-8 rounded-t-[20em] rounded-b-[20em]">
            <h1 className="font-medium opacity-90 text-2xl ml-24 mb-8">Explore course</h1>
            
            <div >
               <div className="flex justify-between">
               <h2 className="font-medium text-xl my-8 ml-28">Web Development</h2>
               <Link to="/manycourses" className=" my-8 mr-28 font-medium text-sm text-blue-800">See All <BiArrowFromLeft className="text-2xl inline-block" /></Link>
               </div>
              <div className="flex w-[1200px] mx-auto">
              <div className="w-[10%] mt-24">

                    <div className="rotate-shake-button border-[10px] w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-blue-500 rounded-3xl px-10 py-2">Frontend</button> </div>
                     </div>

                     <div  className="w-[10%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-orange-500 rounded-3xl px-10 py-2">Backend</button> </div>
                     </div>

                     <div  className="w-[10%] mt-24"> 
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-sky-400 rounded-3xl px-10 py-2">Database</button> </div>
                     </div>

                     <div  className="w-[10%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-pink-500 rounded-3xl px-10 py-2">UI design</button> </div>
                     </div>


                     <div className="w-[30%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-yellow-500 rounded-3xl px-10 py-2">Frontend</button> </div>
                     </div>

                     <div className="relative shadow flex bg-white p-2 justify-between  border-2 border-sky-300  hover:scale-105 transition-all duration-200">
                        <img src="./signup.avif" width="150px" alt="" />
                    <div className="flex flex-col justify-center">
                    <h1 className="font-bold text-center ml-2">Web Development</h1>
                    <p className="text-sm p-2 text-center ">Learn to build and deploy websites rith modern web development skills.</p>
                        <Link to="/manycourses" className="px-8 py-1  bg-blue-600 font-medium  rounded-[20px] text-center mx-auto text-white">Explore</Link>
                         </div>
                </div>
                     
              </div>
            </div>

            <div >
            <div className="flex justify-between">
               <h2 className="font-medium text-xl my-8 ml-28">UI/UX Design</h2>
               <Link to="/manycourses" className=" my-8 mr-28 font-medium text-sm text-blue-800">See All <BiArrowFromLeft className="text-2xl inline-block" /></Link>
               </div>
              <div className="flex w-[1200px] mx-auto">
              <div className="w-[10%] mt-24">

                    <div className="rotate-shake-button border-[10px] w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-blue-500 rounded-3xl px-10 py-2">Frontend</button> </div>
                     </div>

                     <div  className="w-[10%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-orange-500 rounded-3xl px-10 py-2">Backend</button> </div>
                     </div>

                     <div  className="w-[10%] mt-24"> 
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-sky-400 rounded-3xl px-10 py-2">Database</button> </div>
                     </div>

                     <div className="relative ml-16  shadow flex bg-white p-2 justify-between  border-2 border-sky-300  hover:scale-105 transition-all duration-200">
                        <img src="./signup.avif" width="150px" alt="" />
                    <div className="flex flex-col justify-center">
                    <h1 className="font-bold text-center ml-2">UI/UX Design</h1>
                    <p className="text-sm p-2 text-center ">Master UI/UX design principles with hand-on courses. Elevate your skills in user Experience and interface design</p>
                        <Link to="/manycourses" className="px-8 py-1  bg-blue-600 font-medium  rounded-[20px] text-center mx-auto text-white">Explore</Link>
                         </div>
                </div>


                     <div  className="w-[10%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-pink-500 rounded-3xl px-10 py-2">UI design</button> </div>
                     </div>


                     <div className="w-[30%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-yellow-500 rounded-3xl px-10 py-2">Frontend</button> </div>
                     </div>

                
                     
              </div>
            </div>


            <div>
            <div className="flex justify-between">
               <h2 className="font-medium text-xl my-8 ml-28">Database</h2>
               <Link to="/manycourses" className=" my-8 mr-28 font-medium text-sm text-blue-800">See All <BiArrowFromLeft className="text-2xl inline-block" /></Link>
               </div>
              <div className="flex w-[1200px] mx-auto">
              <div className="w-[10%] mt-24">

                    <div className="rotate-shake-button border-[10px] w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-blue-500 rounded-3xl px-10 py-2">Frontend</button> </div>
                     </div>

                     <div className="relative ml-16  shadow flex bg-white p-2 justify-between  border-2 border-sky-300  hover:scale-105 transition-all duration-200">
                        <img src="./signup.avif" width="150px" alt="" />
                    <div className="flex flex-col justify-center">
                    <h1 className="font-bold text-center ml-2">Database</h1>
                    <p className="text-sm p-2 text-center ">Learn database management, SQL, and data modeling. Build and optimize robust database with expert-led courses.</p>
                        <Link to="/manycourses" className="px-8 py-1  bg-blue-600 font-medium  rounded-[20px] text-center mx-auto text-white">Explore</Link>
                         </div>
                </div>

                     <div  className="w-[10%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-orange-500 rounded-3xl px-10 py-2">Backend</button> </div>
                     </div>

                     <div  className="w-[10%] mt-24"> 
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-sky-400 rounded-3xl px-10 py-2">Database</button> </div>
                     </div>

                


                     <div  className="w-[10%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-pink-500 rounded-3xl px-10 py-2">UI design</button> </div>
                     </div>


                     <div className="w-[30%] mt-24">
                    <div className="border-[10px] rotate-shake-button w-[200px] rotate-[75deg] text-center border-white  rounded-3xl px-4 py-1 "> <button className="text-white bg-yellow-500 rounded-3xl px-10 py-2">Frontend</button> </div>
                     </div>

                
                     
              </div>
            </div>

                

        </div>
    )
 }
 export default Courses;