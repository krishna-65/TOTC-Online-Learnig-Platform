

const Logo = ()=>{
    return( 
                <p className="h-[30px] w-[30px] border border-white rotate-45 relative"><span className="-rotate-45 bottom-2 text-lg absolute left-1 text-white font-medium">TOTC</span></p>
    )
}
export default Logo;