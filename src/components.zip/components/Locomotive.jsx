import React, { useEffect, useRef } from 'react';
import LocomotiveScroll from 'locomotive-scroll';
import 'locomotive-scroll/dist/locomotive-scroll.css';
import { useLocation } from 'react-router-dom';

const LocomotiveScrollComponent = ({ children }) => {
  const scrollRef = useRef(null);
  const location = useLocation();

  useEffect(() => {
    const scroll = new LocomotiveScroll({
      el: scrollRef.current,
      smooth: true,
      multiplier: 1,
    });

    return () => {
      if (scroll) scroll.destroy();
    };
  }, [location]);

  return (
    <div ref={scrollRef} data-scroll-container className="scroll-container">
      {children}
    </div>
  );
};

export default LocomotiveScrollComponent;
