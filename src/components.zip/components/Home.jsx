import Navbar from "./Navbar";
import Herosection from "./Herosection";
import OurSuccess from "./OurSuccess";
import AboutSoftware from "./AboutSoftware";
import AboutTOTC from "./AboutTOTC";
import Ourfeatures from "./Ourfeatures";
import Courses from "./Courses";
import Footer from "./Footer";
import Testimonial from "./Testimonial";

const Home = ()=>{
    return (
        <div>
            <Navbar/>
            <Herosection/>
            <OurSuccess />
            <AboutSoftware />
            <AboutTOTC/>        
            <Courses/>
            <Testimonial/>
            <Footer/>
            <div className="h-[20vh] w-[10vw]"></div>
        </div>
    )
}
export default Home;