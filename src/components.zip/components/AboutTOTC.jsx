import { RiLoginBoxLine } from "react-icons/ri";
import { Link } from "react-router-dom";

const AboutTOTC = () =>{
    return (
        <div className="flex justify-center items-center mt-16 p-4 mb-32">
         <div className="w-[80%] ">   <h1 className="text-2xl text-center  font-bold text-blue-800 mb-8">What is <span className="text-blue-400">TOTC?</span> </h1>
            <p className="text-md text-gray-600 text-center mb-8">TOTC is  a platform that allows educator to create online classes whereby they can<br/>store the course material online; manage assignments, quizes and exams, monitor<br/> due dates; grade results and provide students with feedback all in one place.</p>

            <div className="flex flex-col md:flex-row items-center justify-between gap-6 ">
            <div className="relative group w-[90%] md:w-[50%]  hover:scale-105 transition-all duration-200">

            <div className="hidden md:flex absolute  flex-col items-center  md:left-[25%] md:top-[20%] lg:left-[30%] lg:top-1/4 xl:left-[35%] group-hover:opacity-100">
                    <h1 className="text-white font-bold  sm:text-xl  text-md md:text-2xl sm:mb-2 ml-2">For Instructor</h1>
                    <Link to="/register" className =" py-2 px-2 sm:px-4 sm:py-2 rounded-[20px] text-[10px] sm:text-md md:text-[15px] text-white bg-blue-500 " >Go For Signup <RiLoginBoxLine className="inline-block"/></Link> </div>
                    
                <video src="./instructor.mp4.mp4"  autoPlay muted loop className=" mb-8 shadow rounded-md ">
               </video>
                </div>
                <div className="relative group  w-[90%] md:w-[50%]  hover:scale-105 transition-all duration-200">
                    <div className="hidden absolute md:flex flex-col items-center   md:left-[25%] md:top-[18%] lg:left-[28%] xl:left-[35%] lg:top-1/4 group-hover:opacity-100">
                    <h1 className="text-white font-bold  sm:text-xl  text-md md:text-2xl sm:mb-2 ml-2">For Students</h1>
                    <Link to="/register" className =" py-2 px-2 sm:px-4 sm:py-2 rounded-[20px] text-[10px] sm:text-md md:text-[15px] text-white bg-blue-500 " >Go For Signup <RiLoginBoxLine className="inline-block"/></Link> </div>
                    
                <video src="./videoplayback (2).mp4" autoPlay muted loop className=" mb-8 shadow rounded-md ">
               </video>
                </div>
            </div></div>
            <Link to="/manycourses" className="hover:underline">See All</Link>
        </div>
    )

}
export default AboutTOTC;