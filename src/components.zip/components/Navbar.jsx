import { Link } from "react-router-dom";
import Logo from "./Logo";
import { CiMenuBurger } from "react-icons/ci";

const Navbar = ()=>{
    return (
        <div>
          <header className="w-full p-6 flex justify-between md:justify-around items-center bg-teal-500 ">
        <div className="text-white font-bold text-2xl ">
          <Logo className="inline-block h-8 mr-2" />
        </div>
        <nav className="hidden md:block space-x-6 lg:space-x-14 text-white ">
          <a href="#" className="hover:underline">Home</a>
          <Link to="/manycourses" className="hover:underline">Courses</Link>
          <a href="#" className="hover:underline">Careers</a>
          <a href="#" className="hover:underline">Blog</a>
          <a href="#" className="hover:underline">About Us</a>
          <Link to="/login" className="bg-white text-teal-700 px-6 py-2 rounded-[20px] hover:bg-gray-100">Login</Link>
          <Link to="/register" className="bg-teal-700 text-white px-6 py-2 rounded-[20px] border border-white hover:bg-teal-600">Sign Up</Link>
        </nav>
        < CiMenuBurger className="md:hidden text-white  curser-pointer"/>
      </header>
        </div>
        
    )
}
export default Navbar;