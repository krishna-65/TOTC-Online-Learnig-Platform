import { useContext } from "react";
import Navbar from "./Navbar";
import { provideContext } from "../utils/Context";
import CoursesCard from "./CoursesCard";
import Footer from "./Footer";

const ManyCourses = () => {
    // const [data] = useContext(provideContext);
    // console.log(data);

    // if (!Array.isArray(data)) {
    //     // Handle the case when data is not an array
    //     return <p>Loading courses...</p>;
    // }
    
    const data = [
        {title:'Frontend Development', description:'Comprehensive frontend course focusing on modern web development techniques, including responsive design, javascript, and UI/UX principles.', imageUrl:'./frontend.jpeg'},
        {title:'Backend Developmet', description:'Comprehensive frontend course focusing on modern web development techniques, including responsive design, javascript, and UI/UX principles.', imageUrl:'./backend.jpeg'},
        {title:'UI/UX Design', description:'UI/UX design course exploring user-centered design principles, wireframing, proptotyping, and creating intuitive, engaging interfaces.', imageUrl:'./fulldisplay.webp'},
        {title:'MongoDB Database', description:'MongoDB course focused on NoSQL database design, querying, data modeling and performance optimization for scalable applications.', imageUrl:'./database.jpeg'},
        {title:'Fullstack Development', description:'Full stack development course covering both frontend and backend technologies, including web frameworks, databases, and API integration.', imageUrl:'./download.png'},
        {title:'C++ In-depth', description:'IN-depth C++ course exploring advanced programing concepts, object-oriented design, memory management, and efficient algorithm implementation.', imageUrl:'./fulldisplay.webp'}
    ]

    return (
        <div  className="w-[100vw]">
            <Navbar className="bg-white" />
            <div className="p-10 m-5">
                <h2 className="text-3xl  ml-32 font-bold text-[#293972]">Courses</h2>
                <div className="grid grid-cols-1 md:grid-cols-2  md:grid-row-2 lg:grid-row-1 gap-10 lg:grid-cols-3 w-[80%] mt-10 mx-auto space-x-4"> 
                    {data.map((course, i) => (
                        <CoursesCard key={i} data={course} />
                    ))}
                </div>
            </div>
            <Footer/>
            
        </div>
    );
}

export default ManyCourses;
